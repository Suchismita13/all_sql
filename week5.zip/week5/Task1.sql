
CREATE TABLE SubjectAllotments (
    StudentId VARCHAR(20),
    SubjectId VARCHAR(20),
    Is_Valid BIT,
    AllotmentDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE SubjectRequest (
    StudentId VARCHAR(20),
    SubjectId VARCHAR(20),
    RequestDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO SubjectAllotments (StudentId, SubjectId, Is_Valid) VALUES
('159103036', 'PO1491', 1),
('159103036', 'PO1492', 0),
('159103036', 'PO1493', 0),
('159103036', 'PO1494', 0),
('159103036', 'PO1495', 0);


INSERT INTO SubjectRequest (StudentId, SubjectId) VALUES
('159103036', 'PO1496');

-- Create a stored procedure to process subject change requests
DELIMITER //

CREATE PROCEDURE ProcessSubjectRequest()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE student_id VARCHAR(20);
    DECLARE subject_id VARCHAR(20);

    -- Cursor to iterate over the subject change requests
    DECLARE request_cursor CURSOR FOR
        SELECT StudentId, SubjectId FROM SubjectRequest;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Open the cursor
    OPEN request_cursor;

    read_loop: LOOP
        FETCH request_cursor INTO student_id, subject_id;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Mark all previous allotments for the student as invalid
        UPDATE SubjectAllotments
        SET Is_Valid = 0
        WHERE StudentId = student_id AND Is_Valid = 1;

        -- Insert the new subject allotment as valid
        INSERT INTO SubjectAllotments (StudentId, SubjectId, Is_Valid)
        VALUES (student_id, subject_id, 1);

        -- Optionally, delete the processed request
        DELETE FROM SubjectRequest WHERE StudentId = student_id AND SubjectId = subject_id;
    END LOOP;

    -- Close the cursor
    CLOSE request_cursor;
END //

DELIMITER ;

-- Execute the stored procedure to process the subject requests
CALL ProcessSubjectRequest();

-- Check the updated allotments
SELECT * FROM SubjectAllotments;
