WITH CheckInOut AS (
    SELECT 
        EmpID,
        Name,
        [CheckIn-CheckOut Time],
        Attendance,
        ROW_NUMBER() OVER(PARTITION BY EmpID ORDER BY [CheckIn-CheckOut Time]) AS RowNum
    FROM InputTable
),
FirstCheckIn AS (
    SELECT 
        EmpID,
        MIN([CheckIn-CheckOut Time]) AS FirstCheckInTime
    FROM CheckInOut
    WHERE Attendance = 'IN'
    GROUP BY EmpID
),
LastCheckOut AS (
    SELECT 
        EmpID,
        MAX([CheckIn-CheckOut Time]) AS LastCheckOutTime,
        COUNT(*) AS TotalOutCount
    FROM CheckInOut
    WHERE Attendance = 'OUT'
    GROUP BY EmpID
),
WorkHours AS (
    SELECT 
        EmpID,
        SUM(DATEDIFF(MINUTE, [CheckIn-CheckOut Time], LEAD([CheckIn-CheckOut Time]) OVER(PARTITION BY EmpID ORDER BY [CheckIn-CheckOut Time]))) AS TotalWorkMinutes
    FROM CheckInOut
    WHERE Attendance = 'IN'
    GROUP BY EmpID
)
SELECT 
    f.EmpID,
    f.Name,
    CONVERT(date, f.FirstCheckInTime) AS FirstCheckInTime,
    CONVERT(time, f.FirstCheckInTime) AS FirstCheckInTime_HHMM,
    CONVERT(date, l.LastCheckOutTime) AS LastCheckOutTime,
    CONVERT(time, l.LastCheckOutTime) AS LastCheckOutTime_HHMM,
    l.TotalOutCount,
    CONCAT(
        FLOOR(wh.TotalWorkMinutes / 60), ':', 
        RIGHT('00' + CONVERT(varchar, wh.TotalWorkMinutes % 60), 2)
    ) AS TotalWorkHours
FROM FirstCheckIn f
JOIN LastCheckOut l ON f.EmpID = l.EmpID
JOIN WorkHours wh ON f.EmpID = wh.EmpID
ORDER BY f.EmpID;
