SELECT *
FROM Sales.SalesOrderHeader
WHERE CustomerID = (
    SELECT TOP 1 CustomerID
    FROM Sales.SalesOrderHeader
    GROUP BY CustomerID
    ORDER BY COUNT(*) DESC
);
