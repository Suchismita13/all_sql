SELECT TOP 1 soh.*
FROM Sales.SalesOrderHeader soh
JOIN (SELECT SalesOrderID, SUM(UnitPrice * OrderQty) AS OrderTotal
      FROM Sales.SalesOrderDetail
      GROUP BY SalesOrderID) AS order_totals ON soh.SalesOrderID = order_totals.SalesOrderID
ORDER BY order_totals.OrderTotal DESC;
