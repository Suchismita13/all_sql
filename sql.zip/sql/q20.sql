SELECT ShipCountry, COUNT(*) AS NumberOfSales
FROM Sales.SalesOrderHeader
GROUP BY ShipCountry;
