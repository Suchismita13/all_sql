SELECT c.CustomerID 
FROM Sales.Customer c
WHERE NOT EXISTS (SELECT 1 FROM Sales.SalesOrderHeader soh WHERE c.CustomerID = soh.CustomerID);
