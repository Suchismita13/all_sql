SELECT e.BusinessEntityID AS EmployeeID, SUM(soh.TotalDue) AS TotalSales
FROM HumanResources.Employee e
JOIN Sales.SalesOrderHeader soh ON e.BusinessEntityID = soh.SalesPersonID
GROUP BY e.BusinessEntityID;
