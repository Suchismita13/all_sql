WITH EmployeeHierarchy AS (
    SELECT BusinessEntityID, OrganizationNode
    FROM HumanResources.Employee
)
SELECT eh1.BusinessEntityID AS ManagerID, COUNT(eh2.BusinessEntityID) AS NumberOfReports
FROM EmployeeHierarchy eh1
JOIN EmployeeHierarchy eh2 ON eh1.OrganizationNode = eh2.OrganizationNode.GetAncestor(1)
GROUP BY eh1.BusinessEntityID;
