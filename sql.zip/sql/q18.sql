SELECT *
FROM Sales.SalesOrderHeader
WHERE ShipToAddressID IN (
    SELECT AddressID
    FROM Person.Address
    WHERE City = 'Canada'
);