SELECT soh.*
FROM Sales.SalesOrderHeader soh
JOIN (SELECT SalesOrderID, SUM(UnitPrice * OrderQty) AS OrderTotal
      FROM Sales.SalesOrderDetail
      GROUP BY SalesOrderID) AS order_totals ON soh.SalesOrderID = order_totals.SalesOrderID
WHERE order_totals.OrderTotal > 200;
