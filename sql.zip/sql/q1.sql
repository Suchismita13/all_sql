SELECT CustomerID, PersonID, StoreID, AccountNumber, TerritoryID, ModifiedDate 
FROM Sales.Customer;
