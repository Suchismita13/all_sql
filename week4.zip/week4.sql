--week 4

DELIMITER //

CREATE PROCEDURE AllocateSubjects()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE currentStudentId VARCHAR(20);
    DECLARE currentGPA DECIMAL(3, 2);
    DECLARE preference INT;
    DECLARE subjectId VARCHAR(20);
    DECLARE availableSeats INT;

    -- Cursor to iterate over students ordered by GPA in descending order
    DECLARE student_cursor CURSOR FOR
        SELECT StudentId, GPA FROM StudentDetails ORDER BY GPA DESC;

    -- Handlers to manage cursor
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN student_cursor;

    student_loop: LOOP
        FETCH student_cursor INTO currentStudentId, currentGPA;

        IF done THEN
            LEAVE student_loop;
        END IF;

        SET preference = 1;

        preferences_loop: LOOP
            -- Get the subject preference for the current student and preference level
            SELECT SubjectId
            INTO subjectId
            FROM StudentPreference
            WHERE StudentId = currentStudentId AND Preference = preference;

            -- Check if subject has available seats
            SELECT RemainingSeats
            INTO availableSeats
            FROM SubjectDetails
            WHERE SubjectId = subjectId;

            IF availableSeats > 0 THEN
                -- Allocate the subject to the student
                INSERT INTO Allotments (SubjectId, StudentId) VALUES (subjectId, currentStudentId);

                -- Decrement the remaining seats for the allocated subject
                UPDATE SubjectDetails
                SET RemainingSeats = RemainingSeats - 1
                WHERE SubjectId = subjectId;

                LEAVE preferences_loop;
            END IF;

            -- Increment preference
            SET preference = preference + 1;

            -- If all preferences are exhausted, mark the student as unallotted
            IF preference > 5 THEN
                INSERT INTO UnallotedStudents (StudentId) VALUES (currentStudentId);
                LEAVE preferences_loop;
            END IF;
        END LOOP preferences_loop;
    END LOOP student_loop;

    CLOSE student_cursor;
END //

DELIMITER ;
