--level 2 trigeers problem no.2
CREATE TRIGGER CheckStockBeforeInsertOrderDetail
ON Sales.SalesOrderDetail
INSTEAD OF INSERT
AS
BEGIN
    DECLARE @ProductID INT;
    DECLARE @OrderQty INT;
    DECLARE @UnitsInStock INT;

    SELECT @ProductID = i.ProductID, @OrderQty = i.OrderQty
    FROM inserted i;

    SELECT @UnitsInStock = Quantity
    FROM Production.ProductInventory
    WHERE ProductID = @ProductID;

    IF @UnitsInStock < @OrderQty
    BEGIN
        PRINT 'Insufficient stock. Order cannot be placed.';
        RETURN;
    END
    INSERT INTO Sales.SalesOrderDetail (SalesOrderID, ProductID, OrderQty, UnitPrice, UnitPriceDiscount)
    SELECT SalesOrderID, ProductID, OrderQty, UnitPrice, UnitPriceDiscount
    FROM inserted;

    UPDATE Production.ProductInventory
    SET Quantity = Quantity - @OrderQty
    WHERE ProductID = @ProductID;
END;