--leven 2 problem no.3
USE AdventureWorks2014;
GO

IF OBJECT_ID('dbo.GetOrderDetails', 'P') IS NOT NULL
    DROP PROCEDURE dbo.GetOrderDetails;
GO

CREATE PROCEDURE dbo.GetOrderDetails
    @OrderID INT
AS
BEGIN
    SET NOCOUNT ON;

   
    IF NOT EXISTS (
        SELECT 1
        FROM Sales.SalesOrderDetail
        WHERE SalesOrderID = @OrderID
    )
    BEGIN
        PRINT 'The OrderID ' + CAST(@OrderID AS VARCHAR(10)) + ' does not exist';
        RETURN 1;
    END

    
    SELECT *
    FROM Sales.SalesOrderDetail
    WHERE SalesOrderID = @OrderID;
END;
GO
