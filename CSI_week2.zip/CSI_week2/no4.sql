--leven 2 problem no.3
USE AdventureWorks2014;
GO

IF OBJECT_ID('dbo.DeleteOrderDetails', 'P') IS NOT NULL
    DROP PROCEDURE dbo.DeleteOrderDetails;
GO

CREATE PROCEDURE dbo.DeleteOrderDetails
    @OrderID INT,
    @ProductID INT
AS
BEGIN
    SET NOCOUNT ON;

    
    IF @OrderID IS NULL OR @ProductID IS NULL
    BEGIN
        PRINT 'OrderID and ProductID parameters are required.';
        RETURN -1;
    END

    
    IF NOT EXISTS (
        SELECT 1
        FROM Sales.SalesOrderDetail
        WHERE SalesOrderID = @OrderID
    )
    BEGIN
        PRINT 'Invalid OrderID. The provided OrderID does not exist in the Order Details table.';
        RETURN -1;
    END

  
    IF NOT EXISTS (
        SELECT 1
        FROM Sales.SalesOrderDetail
        WHERE SalesOrderID = @OrderID AND ProductID = @ProductID
    )
    BEGIN
        PRINT 'Invalid ProductID. The provided ProductID does not exist in the specified OrderID.';
        RETURN -1;
    END

    
    DELETE FROM Sales.SalesOrderDetail
    WHERE SalesOrderID = @OrderID AND ProductID = @ProductID;

    PRINT 'Order detail for OrderID ' + CAST(@OrderID AS VARCHAR(10)) + ' and ProductID ' + CAST(@ProductID AS VARCHAR(10)) + ' has been successfully deleted.';
    RETURN 0;
END;
GO
