--leven 2 function problem no.2
USE AdventureWorks2014;
GO

IF OBJECT_ID('dbo.FormatDateYYYYMMDD', 'FN') IS NOT NULL
    DROP FUNCTION dbo.FormatDateYYYYMMDD;
GO

CREATE FUNCTION dbo.FormatDateYYYYMMDD
(
    @InputDate DATETIME
)
RETURNS VARCHAR(8)
AS
BEGIN
    DECLARE @FormattedDate VARCHAR(8);
    SET @FormattedDate = CONVERT(VARCHAR(8), @InputDate, 112);
    
    RETURN @FormattedDate;
END;
GO
