--level 2 view problem no.2
CREATE VIEW vw_Orders_Yesterday AS
SELECT 
    SalesOrderID, 
    OrderDate, 
    CustomerID, 
    TotalDue
FROM 
    Sales.SalesOrderHeader
WHERE 
    OrderDate = CAST(DATEADD(DAY, -1, GETDATE()) AS DATE);
