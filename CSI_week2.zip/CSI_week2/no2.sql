--leven 2 problem no.2
USE AdventureWorks2014;
GO

IF OBJECT_ID('dbo.UpdateOrderDetails', 'P') IS NOT NULL
    DROP PROCEDURE dbo.UpdateOrderDetails;
GO

CREATE PROCEDURE dbo.UpdateOrderDetails
    @OrderID INT,
    @ProductID INT,
    @UnitPrice DECIMAL(10, 2) = NULL,
    @Quantity INT = NULL,
    @Discount DECIMAL(5, 2) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CurrentUnitPrice DECIMAL(10, 2);
    DECLARE @CurrentQuantity INT;
    DECLARE @CurrentDiscount DECIMAL(5, 2);
    DECLARE @OriginalQuantity INT;
    DECLARE @NewQuantity INT;
    DECLARE @UnitsInStock INT;
    DECLARE @ReorderPoint INT = 10; 

    
    SELECT 
        @CurrentUnitPrice = UnitPrice,
        @CurrentQuantity = OrderQty,
        @CurrentDiscount = UnitPriceDiscount
    FROM Sales.SalesOrderDetail
    WHERE SalesOrderID = @OrderID AND ProductID = @ProductID;

    SET @UnitPrice = ISNULL(@UnitPrice, @CurrentUnitPrice);
    SET @Quantity = ISNULL(@Quantity, @CurrentQuantity);
    SET @Discount = ISNULL(@Discount, @CurrentDiscount);

    SET @OriginalQuantity = @CurrentQuantity;
    SET @NewQuantity = @Quantity;

    SELECT @UnitsInStock = Quantity
    FROM Production.ProductInventory
    WHERE ProductID = @ProductID;

    IF @UnitsInStock + @OriginalQuantity < @NewQuantity
    BEGIN
        PRINT 'Not enough stock available. Please adjust the quantity.';
        RETURN;
    END

  
    UPDATE Sales.SalesOrderDetail
    SET 
        UnitPrice = @UnitPrice,
        OrderQty = @Quantity,
        UnitPriceDiscount = @Discount
    WHERE SalesOrderID = @OrderID AND ProductID = @ProductID;

    
    IF @@ROWCOUNT = 0
    BEGIN
        PRINT 'Failed to update the order details. Please try again.';
        RETURN;
    END

   
    UPDATE Production.ProductInventory
    SET Quantity = Quantity + @OriginalQuantity - @NewQuantity
    WHERE ProductID = @ProductID;

   
    SELECT @UnitsInStock = Quantity
    FROM Production.ProductInventory
    WHERE ProductID = @ProductID;

    
    IF @UnitsInStock < @ReorderPoint
    BEGIN
        PRINT 'Warning: The quantity in stock of this product has dropped below the reorder point.';
    END
END;
GO
