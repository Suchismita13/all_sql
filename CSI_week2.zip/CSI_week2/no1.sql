--level 2 problem no.1
USE AdventureWorks2014;
GO

IF OBJECT_ID('dbo.InsertOrderDetails', 'P') IS NOT NULL
    DROP PROCEDURE dbo.InsertOrderDetails;
GO

CREATE PROCEDURE dbo.InsertOrderDetails
    @OrderID INT,
    @ProductID INT,
    @UnitPrice DECIMAL(18, 2) = NULL,
    @Quantity INT,
    @Discount DECIMAL(18, 2) = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ProductUnitPrice DECIMAL(18, 2);
    DECLARE @UnitsInStock INT;
    DECLARE @ReorderLevel INT;

 
    IF @Quantity IS NULL
    BEGIN
        PRINT 'Quantity parameter is required.';
        RETURN;
    END

    IF @UnitPrice IS NULL
    BEGIN
        SELECT @UnitPrice = ListPrice
        FROM Production.Product
        WHERE ProductID = @ProductID;

        IF @UnitPrice IS NULL
        BEGIN
            PRINT 'UnitPrice not provided and could not be found in Product table for ProductID ' + CAST(@ProductID AS VARCHAR(10));
            RETURN;
        END
    END

    
    SELECT @UnitsInStock = Quantity
    FROM Production.ProductInventory
    WHERE ProductID = @ProductID;

    IF @UnitsInStock < @Quantity
    BEGIN
        PRINT 'Not enough stock available for ProductID ' + CAST(@ProductID AS VARCHAR(10)) + '. Quantity in stock: ' + CAST(@UnitsInStock AS VARCHAR(10));
        RETURN;
    END


    SELECT @ReorderLevel = ReorderPoint
    FROM Production.Product
    WHERE ProductID = @ProductID;


    INSERT INTO Sales.SalesOrderDetail (SalesOrderID, ProductID, OrderQty, UnitPrice, UnitPriceDiscount)
    VALUES (@OrderID, @ProductID, @Quantity, @UnitPrice, @Discount);

   
    IF @@ROWCOUNT = 0
    BEGIN
        PRINT 'Failed to place the order. Please try again.';
        RETURN;
    END

    
    UPDATE Production.ProductInventory
    SET Quantity = Quantity - @Quantity
    WHERE ProductID = @ProductID;

    
    IF @UnitsInStock - @Quantity < @ReorderLevel
    BEGIN
        PRINT 'Warning: The quantity in stock of ProductID ' + CAST(@ProductID AS VARCHAR(10)) + ' has dropped below its reorder level.';
    END
END;
GO
