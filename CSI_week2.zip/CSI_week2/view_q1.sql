--leven 2 view problem no.1
USE AdventureWorks2014;
GO

IF OBJECT_ID('dbo.vwCustomerOrders', 'V') IS NOT NULL
    DROP VIEW dbo.vwCustomerOrders;
GO

CREATE VIEW dbo.vwCustomerOrders
AS
SELECT 
    c.CustomerID AS CompanyName, 
    soh.SalesOrderID AS OrderID,
    soh.OrderDate,
    sod.ProductID,
    p.Name AS ProductName,
    sod.OrderQty AS QuantityOrdered,
    sod.UnitPrice AS UnitPrice,
    sod.OrderQty * sod.UnitPrice AS TotalPrice
FROM 
    Sales.SalesOrderHeader soh
INNER JOIN 
    Sales.SalesOrderDetail sod ON soh.SalesOrderID = sod.SalesOrderID
INNER JOIN 
    Production.Product p ON sod.ProductID = p.ProductID
INNER JOIN 
    Sales.Customer c ON soh.CustomerID = c.CustomerID;
GO
