--week 3
--task 6
Select Round(ABS(MIN(LAT_N) - MAX(LAT_N)) +ABS(MIN(LONG_W) - MAX(LONG_W)),4) From station ;