--week 3
--task 13

--ratio of cost 
SELECT
    BU,
    Month,
    Cost,
    Revenue,
    ROUND(Cost / NULLIF(Revenue, 0), 2) AS Cost_Revenue_Ratio
FROM
    BU_Financials
ORDER BY
    BU, Month;

--revenue of a BU month on month.
select date_format(order_date,'%b'),sum(price*quantity) 
from products,orders 
where products.product_id=orders.product_id 
group by date_format(order_date,'%b');