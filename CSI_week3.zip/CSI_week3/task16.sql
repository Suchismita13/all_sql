--week 3
--task 16


--for numeric columns
UPDATE employees
SET column1 = column1 + column2,
    column2 = column1 - column2,
    column1 = column1 - column2;


--for string columns
UPDATE employees
SET column1 = column1 || column2,
    column2 = SUBSTRING(column1 FROM 1 FOR CHAR_LENGTH(column1) - CHAR_LENGTH(column2)),
    column1 = SUBSTRING(column1 FROM CHAR_LENGTH(column2) + 1);
