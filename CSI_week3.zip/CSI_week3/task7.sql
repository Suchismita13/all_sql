--week 3
--task 7
select listagg(prime_number,’&’)
within group (order by r)
from
(
select prime_number,
Row_Number() over (order by prime_number) r
from
(
select l prime_number,
count(case l/m when trunc(l/m) then 1 end) count
from
(select level l from dual connect by level <= 1000),
(select level m from dual connect by level <= 1000)
group by l
having count (case l/m when trunc(l/m) then 1 end) in (1,2)
order by l
)
);