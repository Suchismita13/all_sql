--week 3
--task 19

select ceil(avg(salary) - avg(replace(salary, '0', ''))) from employees;