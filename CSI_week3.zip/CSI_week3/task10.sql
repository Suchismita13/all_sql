--week 3
--task 10
select c.company_code, c.founder, count(distinct em.lead_manager_code), count(distinct em.senior_manager_code), count(distinct em.manager_code),count(distinct em.employee_code)
from Company c
join Employee em on (c.company_code = em.company_code)
group by c.company_code, c.founder
order by c.company_code