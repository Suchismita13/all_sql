--week 3
--task 18

--total salary cost and headcount per month for the BU
WITH monthly_cost AS (
    SELECT
        BU,
        month,
        SUM(salary) AS total_salary,
        COUNT(employee_id) AS headcount
    FROM
        employee_salaries
    WHERE
        BU = 'Your_BU_Name' -- Replace with your actual BU name
    GROUP BY
        BU,
        month
)

-- weighted average cost
SELECT
    month,
    total_salary / headcount AS weighted_average_cost
FROM
    monthly_cost
ORDER BY
    month;
