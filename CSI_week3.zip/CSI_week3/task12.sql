--week 3
--task 12
select job_family, country,
       sum(ctc) * 1.0 / sum(case when country = 'India' then sum(ctc) end) over (partition by job_family) as ratio
from t
group by job_family, country;
