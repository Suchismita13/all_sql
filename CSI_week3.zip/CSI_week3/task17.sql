--week 3
--task 17

--Create a login
CREATE LOGIN [username] WITH PASSWORD = 'password';

--Create a user in the database
USE [your_database_name];
CREATE USER [username] FOR LOGIN [username];

--Grant DB_OWNER permissions
ALTER ROLE db_owner ADD MEMBER [username];
