--week 3
--task 14

-- total headcount
SELECT COUNT(*) INTO @total_headcount FROM employees;

--  headcount and percentage for each sub-band
SELECT
    sub_band,
    COUNT(*) AS headcount,
    (COUNT(*) * 100.0 / @total_headcount) AS percentage
FROM
    employees
GROUP BY
    sub_band;
