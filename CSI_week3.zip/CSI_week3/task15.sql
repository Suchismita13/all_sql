--week 3
--task 15
SELECT id, name, salary
FROM (
    SELECT id, name, salary, 
           RANK() OVER (ORDER BY salary DESC) AS salary_rank
    FROM employees
) ranked_employees
WHERE salary_rank <= 5;
