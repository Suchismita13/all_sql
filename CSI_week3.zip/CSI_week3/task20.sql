--week 3
--task 20


INSERT INTO target_table (column1, column2, column3, ...)
SELECT column1, column2, column3, ...
FROM source_table
EXCEPT
SELECT column1, column2, column3, ...
FROM target_table;
